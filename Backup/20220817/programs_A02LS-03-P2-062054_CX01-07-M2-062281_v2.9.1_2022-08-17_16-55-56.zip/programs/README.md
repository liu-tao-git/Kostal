# QNX arm driver

Version: 1.12.0  
SHA1: afa7c5012444d2d5787096259b0589879a132a9e  
